# Ollama 独立使用版

本包仅包含Ollama所需的文件、教程和公开表达规则。

1. 解压下载的ZIP，进入kexing-ollama文件夹。
2. 已装Ollama且有本地模型时，运行ollama list，记下本机模型NAME。
3. 用记事本打开Modelfile.template，将第一行YOUR_INSTALLED_LOCAL_MODEL改为模型NAME，保存为Modelfile，注意不要变成Modelfile.txt。
4. 在该文件夹打开终端，运行：

```text
ollama create kexing-public -f ./Modelfile
ollama run kexing-public
```

本包给已有模型附加指令，不训练或下载新权重。

## 不想配置：直接试用

解压后双击“开始使用.html”，或用记事本打开prompt.txt，复制全文到新聊天即可。新聊天没保留资料时重新粘贴；后续直接对话，无需每次重新点名模仿。

## 检查有没有读对

发送：“今天没什么事，随便聊聊。”
检查它是否直接和你接话，没有问你要回复谁、没有给“你可以这样回”的成稿。再连续聊两轮，语气应持续；问到未提供的真实经历时保留未知。

本公开包不含聊天原文、人物画像或私人记忆；示例是新写演示。各模型的回答仍需本人检查。

源码与完整教程：https://github.com/fuarnos/kexing
许可证：见LICENSE。无需下载其他平台的包。
