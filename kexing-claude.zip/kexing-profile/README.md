# Claude 独立使用版

本包仅包含Claude所需的文件、教程和公开表达规则。

## 直接安装Skill：不用解压

1. 下载kexing-claude.zip。
2. 在Claude打开Customize → Skills → “+”→ Create skill → Upload a skill。
3. 直接选择刚下载的ZIP，启用kexing-profile。不要上传完整多平台包。

如果界面要求开启代码执行与文件创建，按Claude当前设置处理；本技能只有文本与离线教程，没有需要运行的代码。

## 想使用Project

解压后进入kexing-profile文件夹。新建Project，在知识区上传knowledge.txt；Set project instructions中粘贴instructions.txt全文，保存后从项目聊天。

官方入口：https://claude.ai

## 不想配置：直接试用

解压后双击“开始使用.html”，或用记事本打开prompt.txt，复制全文到新聊天即可。新聊天没保留资料时重新粘贴。

## 检查有没有读对

发送：“把这段改成自然微信语气：今晚没空，明天可以先看，但现在不保证做完。”
检查是否保留这三个条件，没有新增亲密称呼或交付承诺。问它是否拥有私人记忆时，应回答没有。

本公开包不含聊天原文、人物画像或私人记忆；示例是新写演示。各模型的回答仍需本人检查。

源码与完整教程：https://github.com/fuarnos/kexing
许可证：见LICENSE。无需下载其他平台的包。
